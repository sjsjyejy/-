package ly.maps.app
import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.google.gson.Gson
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.osmdroid.config.Configuration
import org.osmdroid.events.MapEventsReceiver
import org.osmdroid.tileprovider.modules.OfflineTileProvider
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.tileprovider.util.SimpleRegisterReceiver
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.MapEventsOverlay
import org.osmdroid.views.overlay.Marker
import java.io.File

class Db(val tr:List<Tribe>,val bs:List<Branch>,val fs:List<Family>,val ps:List<Person>,val pl:List<Place>)
class Focus(val kind:String,val id:Long)
class Bk(val tribes:List<Tribe>,val branches:List<Branch>,val families:List<Family>,val people:List<Person>,val places:List<Place>)
val PAL=listOf(0xFF1D4ED8,0xFF15803D,0xFFB91C1C,0xFF7E22CE,0xFFC2410C,0xFF0F766E).map{it.toInt()}
fun c(n:String,v:Long)=n to v.toInt()
val CATS=listOf(c("منزل أو عائلة",0xFF8A6D1D),c("قبيلة",0xFF14505C),c("أرض أو ملكية",0xFF65A30D),c("مدينة أو منطقة أو حي",0xFF6A4C93),c("طريق أو ممر",0xFFC2410C),c("مسجد",0xFF15803D),c("متجر",0xFFBE185D),c("قُبّة",0xFF0E7490),c("معلم أو موقع مهم",0xFF1D4ED8),c("مخصص",0xFF475569))
fun Db.tribeOf(p:Place)=p.tribeId?:fs.find{it.id==p.familyId}?.tribeId
fun Db.branchOf(p:Place)=p.branchId?:fs.find{it.id==p.familyId}?.branchId
fun Db.col(p:Place):Int{val b=bs.find{it.id==branchOf(p)};val t=tr.find{it.id==(tribeOf(p)?:b?.tribeId)};return b?.color?:t?.color?:CATS.find{it.first==p.cat}?.second?:0xFF475569.toInt()}
fun Db.hit(p:Place,f:Focus?)=when(f?.kind){null->true;"tribe"->tribeOf(p)==f.id;"branch"->branchOf(p)==f.id;else->p.familyId==f.id}
fun <T> opt(l:List<T>,id:(T)->Long,n:(T)->String):List<Pair<Long?,String>> = listOf<Pair<Long?,String>>(null to "بدون")+l.map{id(it) to n(it)}

fun setupTiles(c:Context,m:MapView){
 val dir=File(c.getExternalFilesDir(null),"osmdroid");dir.mkdirs()
 val fl=dir.listFiles(java.io.FileFilter{it.extension.lowercase() in setOf("mbtiles","sqlite","zip","gemf")})
 if(fl!=null&&fl.isNotEmpty()){m.setUseDataConnection(false);m.setTileProvider(OfflineTileProvider(SimpleRegisterReceiver(c),fl))}
 m.setTileSource(TileSourceFactory.MAPNIK)}

class MainActivity:ComponentActivity(){
 override fun onCreate(b:Bundle?){super.onCreate(b)
  val base=getExternalFilesDir(null)!!
  Configuration.getInstance().apply{userAgentValue=packageName;osmdroidBasePath=base;osmdroidTileCache=File(base,"tiles")}
  setContent{MaterialTheme{CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl){Surface(Modifier.fillMaxSize()){App(DB.get(this@MainActivity).d())}}}}}}

@Composable fun App(d:D){
 val ctx=LocalContext.current
 val tr by remember{d.tribes()}.collectAsState(emptyList());val bs by remember{d.branches()}.collectAsState(emptyList())
 val fs by remember{d.families()}.collectAsState(emptyList());val ps by remember{d.people()}.collectAsState(emptyList());val pl by remember{d.places()}.collectAsState(emptyList())
 val db=Db(tr,bs,fs,ps,pl)
 var tab by remember{mutableIntStateOf(0)};var focus by remember{mutableStateOf<Focus?>(null)}
 val nav:(Int,Focus?)->Unit={t,f->tab=t;focus=f}
 val map=remember{MapView(ctx).apply{setMultiTouchControls(true);minZoomLevel=4.0;controller.setZoom(6.0);controller.setCenter(GeoPoint(27.0,17.0));setupTiles(ctx,this)}}
 DisposableEffect(Unit){map.onResume();onDispose{map.onPause()}}
 Scaffold(bottomBar={NavigationBar{listOf("الخريطة" to "🗺","القبائل" to "🏷","العائلات" to "🏠","الأشخاص" to "👤","نسخ" to "💾").forEachIndexed{i,t->NavigationBarItem(tab==i,{tab=i},{Text(t.second)},label={Text(t.first,fontSize=11.sp)})}}}){p->
  Box(Modifier.padding(p)){when(tab){0->MapTab(db,d,map,focus,nav);1->TribesTab(db,d,nav);2->FamTab(db,d,nav);3->PeopleTab(db,d,focus,nav);else->BackupTab(db,d)}}}}

@Composable fun Dlg(t:String,ok:String,onOk:()->Unit,onX:()->Unit,cancel:String="إلغاء",c:@Composable ColumnScope.()->Unit)=AlertDialog(onDismissRequest=onX,title={Text(t)},text={Column(Modifier.verticalScroll(rememberScrollState()),content=c)},confirmButton={TextButton(onOk){Text(ok)}},dismissButton={if(cancel.isNotEmpty())TextButton(onX){Text(cancel)}})
@Composable fun Confirm(m:String,yes:()->Unit,x:()->Unit)=Dlg("تأكيد الحذف","حذف",yes,x){Text(m)}
@Composable fun TF(l:String,v:String,on:(String)->Unit)=OutlinedTextField(v,on,Modifier.fillMaxWidth().padding(vertical=4.dp),label={Text(l)})
@Composable fun Dd(label:String,opts:List<Pair<Long?,String>>,sel:Long?,on:(Long?)->Unit){var o by remember{mutableStateOf(false)}
 Box{OutlinedButton({o=true},Modifier.fillMaxWidth()){Text(label+": "+(opts.firstOrNull{it.first==sel}?.second?:"بدون"))}
  DropdownMenu(o,{o=false}){opts.forEach{op->DropdownMenuItem({Text(op.second)},{on(op.first);o=false})}}}}
@Composable fun Dot(k:Int)=Box(Modifier.size(16.dp).background(Color(k),CircleShape))

@Composable fun MapTab(db:Db,d:D,map:MapView,focus:Focus?,nav:(Int,Focus?)->Unit){
 val sc=rememberCoroutineScope();var add by remember{mutableStateOf<GeoPoint?>(null)};var sel by remember{mutableStateOf<Place?>(null)};var del by remember{mutableStateOf<Place?>(null)}
 Box(Modifier.fillMaxSize()){
  AndroidView({map},Modifier.fillMaxSize(),update={m->
   m.overlays.clear()
   m.overlays.add(MapEventsOverlay(object:MapEventsReceiver{override fun singleTapConfirmedHelper(p:GeoPoint?)=false;override fun longPressHelper(p:GeoPoint?):Boolean{add=p;return true}}))
   db.pl.forEach{pl->m.overlays.add(Marker(m).apply{position=GeoPoint(pl.lat,pl.lon);title=pl.name;setAnchor(Marker.ANCHOR_CENTER,Marker.ANCHOR_CENTER)
    icon=GradientDrawable().apply{shape=GradientDrawable.OVAL;setColor(db.col(pl));setStroke(3,-1);setSize(44,44);setAlpha(if(db.hit(pl,focus))255 else 50)}
    setOnMarkerClickListener{_,_->sel=pl;true}})}
   m.invalidate()})
  val tid=when(focus?.kind){"tribe"->focus.id;"branch"->db.bs.find{it.id==focus.id}?.tribeId;else->null}
  Column(Modifier.align(Alignment.TopCenter).background(Color(0xCCFFFFFF)).padding(4.dp)){
   Row(Modifier.horizontalScroll(rememberScrollState())){FilterChip(focus==null,{nav(0,null)},{Text("الكل")});Spacer(Modifier.width(4.dp))
    db.tr.forEach{t->FilterChip(tid==t.id,{nav(0,Focus("tribe",t.id))},{Text(t.name)},leadingIcon={Dot(t.color)});Spacer(Modifier.width(4.dp))}}
   if(tid!=null)Row(Modifier.horizontalScroll(rememberScrollState())){db.bs.filter{it.tribeId==tid}.forEach{b->FilterChip(focus?.kind=="branch"&&focus.id==b.id,{nav(0,Focus("branch",b.id))},{Text(b.name)});Spacer(Modifier.width(4.dp))}}
   Text("اضغط مطولًا على الخريطة لإضافة علامة",fontSize=11.sp)}}
 add?.let{pt->PlaceDlg(pt,db,{x->sc.launch{d.upL(listOf(x))};add=null},{add=null})}
 sel?.let{p->val f=db.fs.find{it.id==p.familyId}
  Dlg(p.name,"إغلاق",{sel=null},{sel=null},""){Text(p.cat+"\n%.6f, %.6f".format(p.lat,p.lon));if(p.notes.isNotBlank())Text(p.notes)
   f?.let{Text("العائلة: "+it.name);TextButton({sel=null;nav(3,Focus("family",it.id))}){Text("أفراد العائلة وشجرتهم")}}
   db.tribeOf(p)?.let{id->TextButton({sel=null;nav(0,Focus("tribe",id))}){Text("إبراز القبيلة")}}
   TextButton({del=p;sel=null}){Text("حذف العلامة")}}}
 del?.let{p->Confirm("حذف العلامة «"+p.name+"»؟",{sc.launch{d.delL(p.id)};del=null},{del=null})}}

@Composable fun PlaceDlg(pt:GeoPoint,db:Db,ok:(Place)->Unit,x:()->Unit){var n by remember{mutableStateOf("")};var c by remember{mutableStateOf<Long?>(0L)};var f by remember{mutableStateOf<Long?>(null)};var s by remember{mutableStateOf("")}
 val cn=CATS[(c?:9L).toInt()].first
 Dlg("علامة جديدة","حفظ",{ok(Place(name=n.ifBlank{cn},cat=cn,lat=pt.latitude,lon=pt.longitude,notes=s,familyId=f))},x){
  Text("%.6f, %.6f".format(pt.latitude,pt.longitude));TF("الاسم",n){n=it};Dd("التصنيف",CATS.mapIndexed{i,k->i.toLong() to k.first},c){c=it}
  Dd("العائلة",opt(db.fs,{it.id},{it.name}),f){f=it};TF("ملاحظات",s){s=it}}}

@Composable fun TribesTab(db:Db,d:D,nav:(Int,Focus?)->Unit){
 val sc=rememberCoroutineScope();var ed by remember{mutableStateOf<Tribe?>(null)};var nb by remember{mutableStateOf<Branch?>(null)};var del by remember{mutableStateOf<Tribe?>(null)};var delB by remember{mutableStateOf<Branch?>(null)}
 LazyColumn(Modifier.fillMaxSize().padding(12.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
  item{Button({ed=Tribe(name="",color=PAL[0])}){Text("قبيلة جديدة")}}
  items(db.tr){t->Card(Modifier.fillMaxWidth()){Column(Modifier.padding(12.dp)){
   Row(verticalAlignment=Alignment.CenterVertically){Dot(t.color);Spacer(Modifier.width(8.dp));Text(t.name,Modifier.weight(1f),style=MaterialTheme.typography.titleMedium)}
   if(t.notes.isNotBlank())Text(t.notes)
   db.bs.filter{it.tribeId==t.id}.forEach{b->Row(verticalAlignment=Alignment.CenterVertically){b.color?.let{Dot(it);Spacer(Modifier.width(4.dp))};Text("فرع "+b.name+" ("+db.fs.count{it.branchId==b.id}+" عائلة)",Modifier.weight(1f));TextButton({nav(0,Focus("branch",b.id))}){Text("الخريطة")};TextButton({nb=b}){Text("تعديل")};TextButton({delB=b}){Text("حذف")}}}
   Text("العائلات: "+db.fs.count{it.tribeId==t.id})
   Row(Modifier.horizontalScroll(rememberScrollState())){TextButton({nav(0,Focus("tribe",t.id))}){Text("الخريطة")};TextButton({nb=Branch(tribeId=t.id,name="")}){Text("فرع جديد")};TextButton({ed=t}){Text("تعديل")};TextButton({del=t}){Text("حذف")}}}}}}
 ed?.let{t->var n by remember{mutableStateOf(t.name)};var k by remember{mutableIntStateOf(t.color)};var s by remember{mutableStateOf(t.notes)}
  Dlg("قبيلة","حفظ",{if(n.isNotBlank()){sc.launch{d.upT(listOf(t.copy(name=n.trim(),color=k,notes=s)))};ed=null}},{ed=null}){TF("الاسم",n){n=it};Row{PAL.forEach{q->Box(Modifier.padding(4.dp).size(if(q==k)36.dp else 28.dp).background(Color(q),CircleShape).clickable{k=q})}};TF("وصف وملاحظات",s){s=it}}}
 nb?.let{b->var n by remember{mutableStateOf(b.name)};var k by remember{mutableStateOf(b.color)}
  Dlg("فرع","حفظ",{if(n.isNotBlank()){sc.launch{d.upB(listOf(b.copy(name=n.trim(),color=k)))};nb=null}},{nb=null}){TF("اسم الفرع",n){n=it};Row(verticalAlignment=Alignment.CenterVertically){TextButton({k=null}){Text("بلون القبيلة")};PAL.forEach{q->Box(Modifier.padding(4.dp).size(if(q==k)36.dp else 28.dp).background(Color(q),CircleShape).clickable{k=q})}}}}
 del?.let{t->Confirm("حذف القبيلة «"+t.name+"» وفروعها؟ تبقى العائلات والعلامات دون ربط.",{sc.launch{d.rmT(t.id)};del=null},{del=null})}
 delB?.let{b->Confirm("حذف الفرع «"+b.name+"»؟",{sc.launch{d.rmB(b.id)};delB=null},{delB=null})}}

@Composable fun FamTab(db:Db,d:D,nav:(Int,Focus?)->Unit){
 val sc=rememberCoroutineScope();var ed by remember{mutableStateOf<Family?>(null)};var del by remember{mutableStateOf<Family?>(null)}
 LazyColumn(Modifier.fillMaxSize().padding(12.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
  item{Button({ed=Family(name="")}){Text("عائلة جديدة")}}
  items(db.fs){f->Card(Modifier.fillMaxWidth()){Column(Modifier.padding(12.dp)){Text(f.name,style=MaterialTheme.typography.titleMedium)
   Text(listOfNotNull(db.tr.find{it.id==f.tribeId}?.name,db.bs.find{it.id==f.branchId}?.name,if(f.head.isNotBlank())"الكبير: "+f.head else null).joinToString("، "))
   Text("المواقع: "+db.pl.count{it.familyId==f.id}+"، الأفراد: "+db.ps.count{it.familyId==f.id})
   Row(Modifier.horizontalScroll(rememberScrollState())){TextButton({nav(0,Focus("family",f.id))}){Text("الخريطة")};TextButton({nav(3,Focus("family",f.id))}){Text("الأفراد")};TextButton({ed=f}){Text("تعديل")};TextButton({del=f}){Text("حذف")}}}}}}
 ed?.let{f->FamDlg(f,db,{x->sc.launch{d.upF(listOf(x.copy(updated=System.currentTimeMillis())))};ed=null},{ed=null})}
 del?.let{f->Confirm("حذف العائلة «"+f.name+"»؟ يبقى الأفراد والعلامات دون ربط.",{sc.launch{d.rmF(f.id)};del=null},{del=null})}}

@Composable fun FamDlg(f:Family,db:Db,ok:(Family)->Unit,x:()->Unit){var n by remember{mutableStateOf(f.name)};var h by remember{mutableStateOf(f.head)};var t by remember{mutableStateOf(f.tribeId)};var b by remember{mutableStateOf(f.branchId)};var s by remember{mutableStateOf(f.notes)}
 Dlg("عائلة","حفظ",{if(n.isNotBlank())ok(f.copy(name=n.trim(),head=h.trim(),tribeId=t,branchId=b,notes=s))},x){
  TF("اسم العائلة",n){n=it};TF("الأب أو كبير الأسرة",h){h=it};Dd("القبيلة",opt(db.tr,{it.id},{it.name}),t){t=it;b=null}
  Dd("الفرع",opt(db.bs.filter{it.tribeId==t},{it.id},{it.name}),b){b=it};TF("ملاحظات",s){s=it}}}

@Composable fun Node(p:Person,all:List<Person>,depth:Int,open:(Person)->Unit){
 val kids=all.filter{it.fatherId==p.id||it.motherId==p.id};var ex by remember{mutableStateOf(depth<1)}
 Row(Modifier.padding(start=(depth*18).dp),verticalAlignment=Alignment.CenterVertically){Text(if(kids.isEmpty())"•" else if(ex)"▾" else "▸",Modifier.clickable{ex=!ex}.padding(10.dp));Text(p.name+if(p.certain)"" else " (غير مؤكد)",Modifier.clickable{open(p)})}
 if(ex&&depth<30)kids.forEach{Node(it,all,depth+1,open)}}

@Composable fun PeopleTab(db:Db,d:D,focus:Focus?,nav:(Int,Focus?)->Unit){
 val sc=rememberCoroutineScope();var q by remember{mutableStateOf("")};var sel by remember{mutableStateOf<Long?>(null)};var ed by remember{mutableStateOf<Person?>(null)};var del by remember{mutableStateOf<Person?>(null)}
 val ff=if(focus?.kind=="family")focus else null
 val list=db.ps.filter{(q.isBlank()||it.name.contains(q))&&(ff==null||it.familyId==ff.id)}
 Column(Modifier.fillMaxSize().padding(12.dp)){
  Row(verticalAlignment=Alignment.CenterVertically){Button({ed=Person(name="",familyId=ff?.id)}){Text("شخص جديد")};if(ff!=null){Spacer(Modifier.width(8.dp));TextButton({nav(3,null)}){Text("عرض الجميع")}}}
  TF("بحث بالاسم",q){q=it}
  LazyColumn{items(list){p->ListItem(headlineContent={Text(p.name)},supportingContent={Text(listOfNotNull(db.ps.find{it.id==p.fatherId}?.let{"ابن "+it.name},db.fs.find{it.id==p.familyId}?.name).joinToString("، "))},modifier=Modifier.clickable{sel=p.id})}}}
 sel?.let{id->db.ps.find{it.id==id}?.let{p->
  Dlg(p.name,"إغلاق",{sel=null},{sel=null},""){
   Text("الأب: "+(db.ps.find{it.id==p.fatherId}?.name?:"غير مسجل")+"\nالأم: "+(db.ps.find{it.id==p.motherId}?.name?:"غير مسجلة"))
   db.fs.find{it.id==p.familyId}?.let{f->Text("العائلة: "+f.name);db.tr.find{it.id==f.tribeId}?.let{Text("القبيلة: "+it.name)};TextButton({sel=null;nav(0,Focus("family",f.id))}){Text("موقع العائلة على الخريطة")}}
   if(!p.certain)Text("النسب غير مؤكد")
   if(p.notes.isNotBlank())Text(p.notes)
   Text("الشجرة:");Node(p,db.ps,0){sel=it.id}
   Row(Modifier.horizontalScroll(rememberScrollState())){TextButton({ed=Person(name="",fatherId=p.id,familyId=p.familyId)}){Text("ابن له")};TextButton({ed=Person(name="",motherId=p.id,familyId=p.familyId)}){Text("ابن لها")};TextButton({ed=p}){Text("تعديل")};TextButton({del=p}){Text("حذف")}}}}}
 ed?.let{p->PerDlg(p,db,{x->sc.launch{d.upP(listOf(x))};ed=null},{ed=null})}
 del?.let{p->Confirm("حذف «"+p.name+"»؟ تبقى علاقات أبنائه دون أب مسجل.",{sc.launch{d.rmP(p.id)};del=null;sel=null},{del=null})}}

@Composable fun PerDlg(p:Person,db:Db,ok:(Person)->Unit,x:()->Unit){var n by remember{mutableStateOf(p.name)};var fa by remember{mutableStateOf(p.fatherId)};var mo by remember{mutableStateOf(p.motherId)};var fm by remember{mutableStateOf(p.familyId)};var c by remember{mutableStateOf(p.certain)};var s by remember{mutableStateOf(p.notes)}
 val others=db.ps.filter{it.id!=p.id}
 Dlg("شخص","حفظ",{if(n.isNotBlank())ok(p.copy(name=n.trim(),fatherId=fa,motherId=mo,familyId=fm,certain=c,notes=s))},x){
  TF("الاسم الكامل",n){n=it};Dd("الأب",opt(others,{it.id},{it.name}),fa){fa=it};Dd("الأم",opt(others,{it.id},{it.name}),mo){mo=it};Dd("العائلة",opt(db.fs,{it.id},{it.name}),fm){fm=it}
  Row(verticalAlignment=Alignment.CenterVertically){Checkbox(c,{c=it});Text("النسب مؤكد")};TF("ملاحظات",s){s=it}}}

@Composable fun BackupTab(db:Db,d:D){val c=LocalContext.current;val sc=rememberCoroutineScope();var msg by remember{mutableStateOf("")}
 val ex=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")){u->if(u!=null){c.contentResolver.openOutputStream(u)?.use{it.write(Gson().toJson(Bk(db.tr,db.bs,db.fs,db.ps,db.pl)).toByteArray())};msg="تم التصدير"}}
 val im=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){u->if(u!=null)sc.launch(Dispatchers.IO){try{val b=Gson().fromJson(c.contentResolver.openInputStream(u)!!.bufferedReader().readText(),Bk::class.java)
  DB.get(c).clearAllTables();d.upT(b.tribes);d.upB(b.branches);d.upF(b.families);d.upP(b.people);d.upL(b.places);msg="تمت الاستعادة"}catch(e:Exception){msg="ملف غير صالح"}}}
 Column(Modifier.padding(16.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(8.dp)){
  Button({ex.launch("libya-maps-backup.json")}){Text("تصدير نسخة احتياطية")}
  OutlinedButton({im.launch(arrayOf("application/json","*/*"))}){Text("استيراد (يستبدل البيانات الحالية)")}
  OutlinedButton({sc.launch{d.seed();msg="أُضيفت بيانات تجريبية (مواقع افتراضية قرب طرابلس)"}}){Text("إضافة بيانات تجريبية")}
  if(msg.isNotEmpty())Text(msg)
  Text("الخرائط دون إنترنت: ضع ملف خرائط (mbtiles أو sqlite أو zip) في المجلد:\n"+File(c.getExternalFilesDir(null),"osmdroid").path+"\nثم أعد تشغيل التطبيق. المناطق التي تصفحتها وأنت متصل تُحفظ مؤقتًا في ذاكرة التخزين.")
  Text("بيانات الأنساب تُحفظ على جهازك فقط ولا تُرسل إلى أي خادم، وما تدخله لا يُعد موثقًا تلقائيًا.")}}
