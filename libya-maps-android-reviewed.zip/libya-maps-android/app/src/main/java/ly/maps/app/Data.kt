package ly.maps.app
import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity data class Tribe(@PrimaryKey(autoGenerate=true) val id:Long=0, val name:String, val color:Int, val notes:String="")
@Entity data class Branch(@PrimaryKey(autoGenerate=true) val id:Long=0, val tribeId:Long, val name:String, val color:Int?=null)
@Entity data class Family(@PrimaryKey(autoGenerate=true) val id:Long=0, val name:String, val head:String="", val tribeId:Long?=null, val branchId:Long?=null, val notes:String="", val created:Long=System.currentTimeMillis(), val updated:Long=System.currentTimeMillis())
@Entity data class Person(@PrimaryKey(autoGenerate=true) val id:Long=0, val name:String, val fatherId:Long?=null, val motherId:Long?=null, val spouseId:Long?=null, val familyId:Long?=null, val certain:Boolean=true, val notes:String="")
@Entity data class Place(@PrimaryKey(autoGenerate=true) val id:Long=0, val name:String, val cat:String, val lat:Double, val lon:Double, val notes:String="", val tribeId:Long?=null, val branchId:Long?=null, val familyId:Long?=null, val personId:Long?=null)

@Dao interface D {
 @Query("SELECT * FROM Tribe") fun tribes():Flow<List<Tribe>>
 @Query("SELECT * FROM Branch") fun branches():Flow<List<Branch>>
 @Query("SELECT * FROM Family") fun families():Flow<List<Family>>
 @Query("SELECT * FROM Person") fun people():Flow<List<Person>>
 @Query("SELECT * FROM Place") fun places():Flow<List<Place>>
 @Upsert suspend fun upT(l:List<Tribe>)
 @Upsert suspend fun upB(l:List<Branch>)
 @Upsert suspend fun upF(l:List<Family>)
 @Upsert suspend fun upP(l:List<Person>)
 @Upsert suspend fun upL(l:List<Place>)
 @Query("DELETE FROM Tribe WHERE id=:i") suspend fun delT(i:Long)
 @Query("DELETE FROM Branch WHERE tribeId=:i") suspend fun delBT(i:Long)
 @Query("DELETE FROM Branch WHERE id=:i") suspend fun delB(i:Long)
 @Query("DELETE FROM Family WHERE id=:i") suspend fun delF(i:Long)
 @Query("DELETE FROM Person WHERE id=:i") suspend fun delP(i:Long)
 @Query("DELETE FROM Place WHERE id=:i") suspend fun delL(i:Long)
 @Query("UPDATE Family SET tribeId=NULL,branchId=NULL WHERE tribeId=:i") suspend fun unT1(i:Long)
 @Query("UPDATE Place SET tribeId=NULL,branchId=NULL WHERE tribeId=:i") suspend fun unT2(i:Long)
 @Query("UPDATE Family SET branchId=NULL WHERE branchId=:i") suspend fun unB1(i:Long)
 @Query("UPDATE Place SET branchId=NULL WHERE branchId=:i") suspend fun unB2(i:Long)
 @Query("UPDATE Place SET familyId=NULL WHERE familyId=:i") suspend fun unF1(i:Long)
 @Query("UPDATE Person SET familyId=NULL WHERE familyId=:i") suspend fun unF2(i:Long)
 @Query("UPDATE Person SET fatherId=NULL WHERE fatherId=:i") suspend fun unP1(i:Long)
 @Query("UPDATE Person SET motherId=NULL WHERE motherId=:i") suspend fun unP2(i:Long)
}
suspend fun D.rmT(i:Long){unT1(i);unT2(i);delBT(i);delT(i)}
suspend fun D.rmB(i:Long){unB1(i);unB2(i);delB(i)}
suspend fun D.rmF(i:Long){unF1(i);unF2(i);delF(i)}
suspend fun D.rmP(i:Long){unP1(i);unP2(i);delP(i)}
suspend fun D.seed(){
 upT(listOf(Tribe(1,"قبيلة تجريبية",0xFF1D4ED8.toInt())))
 upB(listOf(Branch(1,1,"الفرع الأول"),Branch(2,1,"الفرع الثاني")))
 upF(listOf(Family(id=1,name="عائلة أ",head="أحمد",tribeId=1,branchId=1),Family(id=2,name="عائلة ب",head="سالم",tribeId=1,branchId=2)))
 upP(listOf(Person(id=1,name="أحمد",familyId=1),Person(id=2,name="محمد بن أحمد",fatherId=1,familyId=1),Person(id=3,name="علي بن أحمد",fatherId=1,familyId=1),Person(id=4,name="سالم",familyId=2)))
 upL(listOf(Place(id=1,name="منزل عائلة أ",cat="منزل أو عائلة",lat=32.8872,lon=13.1913,familyId=1),Place(id=2,name="منزل عائلة ب",cat="منزل أو عائلة",lat=32.9,lon=13.25,familyId=2)))
}
@Database(entities=[Tribe::class,Branch::class,Family::class,Person::class,Place::class],version=1,exportSchema=false)
abstract class DB:RoomDatabase(){abstract fun d():D
 companion object{@Volatile private var i:DB?=null
  fun get(c:Context):DB=i?:synchronized(this){i?:Room.databaseBuilder(c.applicationContext,DB::class.java,"ly.db").build().also{i=it}}}}
